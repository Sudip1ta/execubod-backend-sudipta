
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Package List</title>
    <?php echo $__env->make('admin.include.path', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</head>
<body>

    <?php echo $__env->make('admin.include.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <main style="margin-top: 58px;">
            <div class="container pt-4">
                <div class="col-md-12">
                    <h5>All Packages <a href="<?php echo e(url('admin/package-create')); ?>" style="float: right;margin-bottom:20px;" class="btn btn-primary btn-xs">Add Package</a></h5>

                    <?php if(session()->has('success')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session()->get('success')); ?>

                        </div>
                    <?php endif; ?>
                </div>
                <div class="col-md-12">
                    <table class="table mt-2">
                        <thead class="table-primary">
                            <th>Pack No.</th>
                            <th>Package Name</th>
                            <th>Goal</th>
                            <th>Level</th>
                            <th>Weeks</th>
                            <th>Days/Week</th>
                            <th>Workout Time / Day</th>
                            <th>Total Duration</th>
                            <th>Free Days</th>
                            <th>Amount</th>
                            <th>Action</th>
                        </thead>
                        <tbody>
                            <?php
                                $sl = 1;
                            ?>
                            <?php if(count($get_packages) > 0): ?>
                                <?php $__currentLoopData = $get_packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $packages_details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <tr id="tr_<?=$packages_details->id;?>">
                                        <input type="hidden" class="pack_id" value="<?php echo e($packages_details->id); ?>">
                                        <input type="hidden" class="status" value="<?php echo e($packages_details->status); ?>"> 
                                        <td><?php echo e($sl++); ?></td>
                                        <td class="pack_name"><?php echo e($packages_details->title); ?></td>
                                        <td class="goal"><?php echo e($packages_details->main_goal); ?></td>
                                        <td class="level"><?php echo e($packages_details->level); ?></td>
                                        <td class="weeks"><?php echo e($packages_details->weeks); ?></td>
                                        <td class="days"><?php echo e($packages_details->avg_days); ?></td>
                                        <td class="time_per_day"><?php echo e($packages_details->avg_workout_time_per_day); ?> MIN</td>
                                        <td class="duration"><?php echo e($packages_details->total_duration); ?> MIN</td>
                                       
                                        <td class="free"><?php echo e($packages_details->free_days); ?></td>
                                        <td class="cost"><i class="fa-solid fa-dollar-sign"></i> <?php echo e($packages_details->cost); ?></td>
                                        <td>
                                            <input type="checkbox" class="pack_status" <?= $packages_details->status == 0 ? 'checked' : ''?> >&nbsp;&nbsp;
                                            <i class="fa-solid fa-circle-info packInfo"></i>&nbsp;
                                           
                                            <i class="fa-solid fa-trash-can deletePack"></i>
                                            
                                        
                                        </td>
                                    </tr>   
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </tbody>
                        
                    </table>
                </div>
            </div>
        </main>

    <?php echo $__env->make('admin.include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\execubod\resources\views/admin/packages/packages_list.blade.php ENDPATH**/ ?>