
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Free Trial</title>
    <?php echo $__env->make('admin.include.path', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</head>
<body>

    <?php echo $__env->make('admin.include.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <main style="margin-top: 58px;">
            <div class="container pt-4">
                <div class="col-md-12">
                    <h6>7 days Free Trial Users</h6>
                </div>
                

                <div class="col-md-12">
                    <table class="userTable mt-2">
                        <thead class="table-primary">
                            <th>Sl No.</th>
                            <th>Name</th>
                            <th>Package Name</th>
                            <th>Amount</th>
                            <th>Apply On</th>
                            <th>End Date</th>
                            <th>Status</th>
                        </thead>
                        <tbody>
                            <?php
                                $sl = 1;
                            ?>
                            <?php if(count($list) > 0): ?>
                                <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php

                                       if($list_data->status == 0){
                                            $status = "Under Trail";
                                       } else if($list_data->status == 1){
                                            $status = "Complete Trail";
                                       }else{
                                        $status = "Cancel";
                                       }
                                    ?>

                                    <tr id="tr_<?=$list_data->id;?>">
                                        <input type="hidden" class="user" value="<?php echo e($list_data->user_id); ?>">
                                        
                                        <td><?php echo e($sl++); ?></td>
                                        <td class=""><a href="<?= url('/').'/admin/'.$list_data->user_id.'/user-information'?>"><?php echo e($list_data->first_name.' '.$list_data->last_name); ?></a></td>
                                        <td class=""><a href="<?= url('/').'/admin/'.$list_data->id.'/package-details'?>"><?php echo e($list_data->title); ?></a></td>

                    
                                        <td class=""><i class="fa-solid fa-dollar-sign"></i> <?php echo e($list_data->amount); ?></td>

                                        <td><?php echo e(date('d-m-Y',strtotime($list_data->created_at))); ?></td>
                                        <td><?php echo e(date('d-m-Y',strtotime($list_data->trial_end_date))); ?></td>
                                        <td> <?php echo e($status); ?></td>

                                       
                                    </tr>   
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </tbody>
                        
                    </table>
                </div>
            </div>
        </main>

    <?php echo $__env->make('admin.include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\execubod\resources\views/admin/user/user_free_trial.blade.php ENDPATH**/ ?>