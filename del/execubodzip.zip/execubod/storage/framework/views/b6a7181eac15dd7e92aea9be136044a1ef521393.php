
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>New Goal Add</title>
    <?php echo $__env->make('admin.include.path', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</head>
<body>

    <?php echo $__env->make('admin.include.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <main style="margin-top: 58px;">
            <div class="container pt-4">
                <h6>New Goal </h6>
                
                <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo e($error); ?><br>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <?php endif; ?>

                <form method="post" action="<?php echo e(url('admin/goal-store')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="row mt-4">
                        <div class="col-md-6">
                            <label for="goal_name">Goal Name</label>
                            <input type="text" name="goal_name" id="goal_name" class="form-control" >
                        </div>

                    </div>

                    <div class="row mt-2">
                        <div class="col-md-6">
                            <label for="note">Note</label>
                            <textarea name="note" id="note" class="form-control" cols="10" rows="5"></textarea>
                        </div>
                    </div>

                    <button type="submit" class="btn btn-primary mt-3">Submit</button>
                </form>
            </div>
        </main>

    <?php echo $__env->make('admin.include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\execubod\resources\views/admin/goal/goal_add.blade.php ENDPATH**/ ?>