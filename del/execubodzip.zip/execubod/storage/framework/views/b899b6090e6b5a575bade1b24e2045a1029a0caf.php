  

</body>


<script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js" ></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js" ></script>
<script type="text/javascript" src="https://code.jquery.com/jquery-2.1.4.min.js"></script>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
<script src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js"></script>
    <script>
        const APP_URI = "<?php echo e(url('/')); ?>";
        $(".userTable").dataTable({
            "pageLength" : 20,
            "order" : []
        });

        $(".introTable").dataTable({
            "pageLength" : 20,
            "order" : []
        });

        $(".categoryTable").dataTable({
            "pageLength" : 20,
            "order" : []
        });

        $('.editUser').click(function (e) { 
            e.preventDefault();
            var user = $(this).parent('td').parent('tr').find('.user').val();
            var name = $(this).parent('td').parent('tr').find('.name').text().split(' ');
            var userName = $(this).parent('td').parent('tr').find('.userName').text();
            var email = $(this).parent('td').parent('tr').find('.email').text();
            var gender = $(this).parent('td').parent('tr').find('.gender').val();

            $("#user_id").val(user);
            $("#first_name").val(name[0]);
            $("#last_name").val(name[1]);
            $("#email").val(email);
            $("#user_name").val(userName);
            $("#gender").val(gender).change();
        });


        $('.save_changes').click(function (e) { 
            e.preventDefault();
            var errorMsg = '';
            var userId = $("#user_id").val();
            var first_name = $("#first_name").val();
            var last_name = $("#last_name").val();
            var email = $("#email").val();
            var user_name = $("#user_name").val();
            var gender = $("#gender").val();
            var CSRF = "<?php echo e(csrf_token()); ?>";
            //var status = $("input[name='status']").val();

            $.ajax({
                type: "POST",
                url: APP_URI+"/admin/user-edit-store",
                data: {
                    first_name :first_name,
                    last_name : last_name,
                    email : email,
                    user_name : user_name,
                    gender : gender,
                    _token: CSRF,
                    user_id : userId,
                },
                success: function (response) {
                   if(response.status == 1){
                       
                       $.each(response.errors, function(index, value){
                            errorMsg+=value+"<br>";   
                       });

                        $(".alert-danger").show();
                        $(".alert-danger").html(errorMsg);
                   }else{
               
                   
                        var gender = response.a.gender == 1 ? 'Male' : (response.a.gender == 2 ? 'Female' : 'Transgender');

                        $("#tr_"+userId).find('.name').text(response.a.first_name+' '+response.a.last_name);
                        $("#tr_"+userId).find('.userName').text(response.a.user_name);
                        $("#tr_"+userId).find('.email').text(response.a.email);
                        $("#tr_"+userId).find('.gender').val(response.a.gender);
                        $("#tr_"+userId).find('.status').val(response.a.status);
                        $("#tr_"+userId).find('.genderText').text(gender);
                        
                        $(".alert-danger").hide();
                        $(".alert-danger").html('');
                        $(".cl").trigger('click');
                        swal({
                            title: "Success!",
                            text: "User Data Updated Successfully!",
                            icon: "success",
                            button: "Ok!",
                        });
                   }
                }
            });
            
            
        });

        $('.deleteUser').click(function(){
            var that = $(this).parent('td').parent('tr');
            var user = $(this).parent('td').parent('tr').find('.user').val();

            swal({
      title: "Are you sure?",
      text: "Do You Want to Delete this Record ?",
      icon: "warning",
      buttons: [
        'No, cancel it!',
        'Yes, I am sure!'
      ],
      dangerMode: true,
    }).then(function(isConfirm) {
      if (isConfirm) {
            $.ajax({
                type: "GET",
                url: APP_URI+"/admin/user-delete",
                data: { user_id : user},
                success: function (response) {
                    console.log(response);
                    if(response.status == 1){
                        that.remove();
                        swal({
                            title: 'Success!',
                            text: 'User successfully deleted!',
                            icon: 'success'
                        });
                    }
                   
                }
            });
        
        } else {
            swal("Cancelled", "Your imaginary record is safe :)", "error");
        }
    });
        });


        $(".status_check").click(function(){

            that = $(this);
            var user = $(this).parent('td').parent('tr').find('.user').val();

            if($(this).is(":checked")){
                $.ajax({
                    type: "GET",
                    url: APP_URI+"/admin/user-status-update",
                    data: {user_id: user, update : 0},
                    success: function (response) {
                        swal({
                            title: "Success!",
                            text: "User is now Active!",
                            icon: "success",
                            button: "Ok!",
                        });
                    }
                });
            }else{
                
                $.ajax({
                    type: "GET",
                    url: APP_URI+"/admin/user-status-update",
                    data: {user_id: user, update : 1},
                    success: function (response) {
                        swal({
                            title: "Success!",
                            text: "User is now Inactive!",
                            icon: "success",
                            button: "Ok!",
                        });
                    }
                });
            }
        });


        $('.editIntro').click(function (e) { 
            e.preventDefault();
            var introId = $(this).parent('td').parent('tr').find('.id').val();
            var short_description = $(this).parent('td').parent('tr').find('.shrt_des').text();
            var description = $(this).parent('td').parent('tr').find('.des').text();
          
            $("#short_des_modal").val(short_description);
            $("#description_modal").val(description);
            $("#intro_id").val(introId);
        });


        $('.save_changes_intro').click(function (e) { 
            e.preventDefault();
            var errorMsg = '';
            var intro_id = $("#intro_id").val();
            var shrt_des = $("#short_des_modal").val();
            var des = $("#description_modal").val();
            var CSRF = "<?php echo e(csrf_token()); ?>";

            $.ajax({
                type: "POST",
                url: APP_URI+"/admin/intro-update",
                data: {
                    intro_id : intro_id,
                    shrt_des : shrt_des,
                    des : des,
                    _token : CSRF
                },
                success: function (response) {

                    if(response.status == 2){
                        $.each(response.errors, function(index, value){
                            errorMsg+=value+"<br>";   
                        });

                        $(".alert-danger").show();
                        $(".alert-danger").html(errorMsg);
                    }else{
                        if(response.status == 1){
                            $("#tr_"+intro_id).find('.shrt_des').text(response.data.short_description);
                            $("#tr_"+intro_id).find('.des').text(response.data.description);
                            $(".cl").trigger('click');

                            swal({
                                title: 'Success!',
                                text: 'App Intro successfully Updated!',
                                icon: 'success'
                            });

                        }else{
                            swal({
                                title: 'Error!',
                                text: 'Some Error Occured!',
                                icon: 'error'
                            });
                        }
                    }
                }
            });
        });


        $('.deleteIntro').click(function(){
            var that = $(this).parent('td').parent('tr');
            var intro_id = $(this).parent('td').parent('tr').find('.id').val();

            var token = "<?php echo e(csrf_token()); ?>";

            swal({
                title: "Are you sure?",
                text: "Do You Want to Delete this Record ?",
                icon: "warning",
                buttons: [
                    'No, cancel it!',
                    'Yes, I am sure!'
                ],
                dangerMode: true,
                }).then(function(isConfirm) {

                if (isConfirm) {
                        $.ajax({
                            type: "POST",
                            url: APP_URI+"/admin/intro-delete",
                            data: { id : intro_id , _token : token},
                            success: function (response) {
                                   
                                if(response.status == 1){
                                    that.remove();
                                    swal({
                                        title: 'Success!',
                                        text: 'Intro successfully deleted!',
                                        icon: 'success'
                                    });
                                }
                            
                            }
                        });
                    
                    } else {
                        swal("Cancelled", "Your imaginary record is safe :)", "error");
                    }
                });
            });


            $(".intro_status").click(function(){

                that = $(this);
                var id = $(this).parent('td').parent('tr').find('.id').val();

                var token = "<?php echo e(csrf_token()); ?>";

                if($(this).is(":checked")){
                    update = 0;
                }else{
                    update = 1;
                }

                $.ajax({
                        type: "POST",
                        url: APP_URI+"/admin/intro-status-update",
                        data: {id: id, update :update, _token : token },
                        success: function (response) {
                            if(response.status == 1)
                            {
                                if(update == 0){
                                    swal({
                                        title: "Success!",
                                        text: "Intro is now Active!",
                                        icon: "success",
                                        button: "Ok!",
                                    });
                                }else{
                                    swal({
                                        title: "Success!",
                                        text: "Intro is now Inactive!",
                                        icon: "success",
                                        button: "Ok!",
                                    });
                                }
                            }
                        }
                    });
            });


            $('.editCategory').click(function (e) { 
                e.preventDefault();
                var category_id = $(this).parent('td').parent('tr').find('.category_id').val();
                var category_name = $(this).parent('td').parent('tr').find('.category_name').text();
                var note = $(this).parent('td').parent('tr').find('.note').text();
                var position = $(this).parent('td').parent('tr').find('.position').text();
                
                $("#category_name_modal").val(category_name);
                $("#position").val(position);
                $("#description_modal").val(note);
                $("#category_id_modal").val(category_id);
            });

            $('.save_changes_category').click(function (e) { 
            e.preventDefault();
            var errorMsg = '';

            var category_id = $("#category_id_modal").val();
            var category_name = $("#category_name_modal").val();
            var position = $("#position").val();
            var note = $("#description_modal").val();
            var CSRF = "<?php echo e(csrf_token()); ?>";

            $.ajax({
                type: "POST",
                url: APP_URI+"/admin/category-update",
                data: {
                    category_id : category_id,
                    category_name : category_name,
                    position : position,
                    note : note,
                    _token : CSRF
                },
                success: function (response) {

                    if(response.status == 2){
                        $.each(response.errors, function(index, value){
                            errorMsg+=value+"<br>";   
                        });

                        $(".alert-danger").show();
                        $(".alert-danger").html(errorMsg);
                    }else{
                        if(response.status == 1){

                            $("#tr_"+category_id).find('.category_name').text(response.data.category_name);
                            $("#tr_"+category_id).find('.note').text(response.data.note);
                            $("#tr_"+category_id).find('.position').text(response.data.position);
                            $(".cl").trigger('click');

                            swal({
                                title: 'Success!',
                                text: 'Category successfully Updated!',
                                icon: 'success'
                            });

                        }else{
                            swal({
                                title: 'Error!',
                                text: 'Some Error Occured!',
                                icon: 'error'
                            });
                        }
                    }
                }
            });
        });


    
    </script>
</html><?php /**PATH C:\xampp\htdocs\apiKey\resources\views/admin/include/footer.blade.php ENDPATH**/ ?>