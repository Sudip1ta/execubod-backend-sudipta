
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>New Excercise Add</title>
    <?php echo $__env->make('admin.include.path', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</head>
<body>

    <?php echo $__env->make('admin.include.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <main style="margin-top: 58px;">
            <div class="container pt-4">
                <h6>New Excercise </h6>
                
                <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo e($error); ?><br>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <?php endif; ?>

                <form method="post" action="<?php echo e(url('admin/excercise-store')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="row mt-4">
                        <div class="col-md-6">
                            <label for="category">Category</label>
                            <select name="category" class="form-control" id="category" required>
                                <option value="" selected disabled>--Select--</option>
                                <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category_list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($category_list->id); ?>"><?php echo e($category_list->category_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="col-md-6">
                            <label for="goal">Goal</label>
                            <select name="goal" class="form-control" id="goal" required>
                                <option value="" selected disabled>--Select--</option>
                                <?php $__currentLoopData = $goal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $goal_list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($goal_list->id); ?>"><?php echo e($goal_list->goal_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                    </div>

                    <div class="row mt-2">
                        <div class="col-md-6">
                            <label for="excercise_name">Excercise Name</label>
                            <input type="text" name="excercise_name" id="excercise_name" class="form-control" required>
                        </div>

                        <div class="col-md-6">
                            <label for="position">Position</label>
                            <input type="number" name="position" id="position" class="form-control" required>
                        </div>
                    </div>

                    <div class="row mt-2">
                        <div class="col-md-12">
                            <label for="note">Note</label>
                            <textarea name="note" id="note" class="form-control" cols="10" rows="5"></textarea>
                        </div>
                    </div>

                    <button type="submit" class="btn btn-primary mt-3">Submit</button>
                </form>
            </div>
        </main>

    <?php echo $__env->make('admin.include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\execubod\resources\views/admin/excercise/excercise_add.blade.php ENDPATH**/ ?>