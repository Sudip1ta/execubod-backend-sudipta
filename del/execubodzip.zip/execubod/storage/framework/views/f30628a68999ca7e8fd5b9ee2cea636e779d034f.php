
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Dashboard</title>
    <?php echo $__env->make('admin.include.path', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</head>
<body>

    <?php echo $__env->make('admin.include.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <main style="margin-top: 58px;">
            <div class="container pt-4">
                <div class="col-md-12">
                    <h5>All Packages <a href="<?php echo e(url('admin/package-create')); ?>" style="float: right;margin-bottom:20px;" class="btn btn-primary btn-xs">Add Package</a></h5>
                </div>
                <div class="col-md-12">
                    <table class="table mt-2">
                        <thead class="table-primary">
                            <th>Sl No.</th>
                            <th>Name</th>
                            <th>User Name</th>
                            <th>Email</th>
                            <th>Gender</th>
                            <th>Last Login</th>
                            <th>Register At</th>
                            <th>Action</th>
                        </thead>
                        <tbody>
                            
                        </tbody>
                        
                    </table>
                </div>
            </div>
        </main>

    <?php echo $__env->make('admin.include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\execubod\resources\views/admin/packages_list.blade.php ENDPATH**/ ?>